/*
 * @(#)InfixExpressionT.java
 */

package javax.ide.model.java.source.tree;

/**
 * An expression involving an infix operation (but not an assignment
 * operation). Infix expressions usually have two operands.
 * Commutative and associative operators may have more than two. The
 * infix operators are: <p/>
 *
 * <pre>
 *   + - * / % && || & | ^ instanceof
 * </pre>
 *
 * @author Andy Yu
 * */
public interface InfixExpressionT
  extends OperatorExpressionT
{
}
