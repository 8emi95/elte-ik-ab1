/*
 * @(#)ConstructorD.java
 */

package javax.ide.model.java.declaration;

/**
 * Represents a constructor.
 *
 * @author Andy Yu
 */
public interface ConstructorD
  extends ExecutableD
{
  // ----------------------------------------------------------------------
}
