/*
 * @(#)TypecastExpressionT.java
 */

package javax.ide.model.java.source.tree;

/**
 * An expression performing a typecast operation. Though technically,
 * a typecast is a prefix operation, it is here represented separately
 * because it has two operands (a type lhs and an expression rhs) and
 * it is not commonly thought of as a typical prefix operator.
 *
 * @author Andy Yu
 * */
public interface TypecastExpressionT
  extends OperatorExpressionT
{
}
