package javax.ide.extension.spi;

import javax.xml.stream.Location;

import org.xml.sax.Locator;


public class XMLParsingUtils
{
  public static LocationAdapter copyAndCastToLocationAdapter(Object locator) {
    if (locator instanceof LocationAdapter) return ((LocationAdapter) locator).copyMe();
    else if (locator instanceof LocatorImpl) return new LocationAdapterImpl( (Locator) locator);
    else if (locator instanceof LocationImpl) return new LocationAdapterImpl( (Location) locator );
    else if (locator instanceof Locator) return new LocationAdapterImpl( new LocatorImpl((Locator) locator) );
    else if (locator instanceof Location) return new LocationAdapterImpl( new LocationImpl((Location) locator) );
    else throw new IllegalArgumentException("XML locator passed in was of type " + locator.getClass().getName());
  }
}
